# AutoHub
Projeto de Aplicações Móveis - Desenvolvimento de Software - ISTEC

*Membros do grupo*

 André Rodrigues- 2022045
 Filipe Gonçalves- 2022120
 Jesus Sanchez- 2022044
 Rohit Lama- 2022321


*Descrição da app*

Loja online de peças automóveis





* Erros*
  .. 
* Funcionalidades não implementadas*
...






