document.addEventListener("DOMContentLoaded", function () {
    // Function to retrieve car parts data from Local Storage
    function getCarPartsFromLocalStorage() {
        const carPartsJSON = localStorage.getItem("carParts");
        return carPartsJSON ? JSON.parse(carPartsJSON) : [];
    }

    // Function to save car parts data to Local Storage
    function saveCarPartsToLocalStorage(carParts) {
        localStorage.setItem("carParts", JSON.stringify(carParts));
    }

    function saveCartItemsToLocalStorage(cartItems) {
        const cartItemsJSON = JSON.stringify(cartItems);
        localStorage.setItem("cartItems", cartItemsJSON);
    }

    // Function to add a new car part to the dataset
    function addCarPart(name, category, price) {
        const carParts = getCarPartsFromLocalStorage();
        const newPart = { name, category, price };
        carParts.push(newPart);
        saveCarPartsToLocalStorage(carParts); // Update Local Storage
    }

    function addToCart(component) {
        const cartItems = getCartItemsFromLocalStorage();
        cartItems.push(component);
        saveCartItemsToLocalStorage(cartItems);
    }

    // Function to display components in the UI
    function displayComponents(components) {
        const componentsContainer = document.querySelector(".components");
        componentsContainer.innerHTML = "";

        components.forEach(component => {
            const componentDiv = document.createElement("div");
            componentDiv.classList.add("component");
            const randomImage = getRandomImageForCategory(component.category);
            componentDiv.innerHTML = `
                <img src="${randomImage}" alt="${component.name}" class="img-fluid">
                <h2>${component.name}</h2>
                <p>Category: ${component.category}</p>
                <p>Price: ${component.price}</p>
                <button class="btn btn-danger" onClick="addPartToCart">Comprar</button>
            `;
            componentsContainer.appendChild(componentDiv);
        });
    }

    function getCartItemsFromLocalStorage() {
        const cartItemsJSON = localStorage.getItem("shoppingCart");
        return JSON.parse(cartItemsJSON) || [];
    }

    function getRandomImageForCategory(category) {
        const engineImages = ["engine1.jpg", "engine2.jpg", "engine3.png"];
        const brakesImages = ["brakes1.jpg", "brakes2.jpg", "brakes3.jpg"];
        const tiresImages = ["tire1.jpg", "tire2.jpg", "tire3.jpg"];
        const filterImages = ["filter1.jpg", "filter2.jpg", "filter3.jpg"];
        const electricImages = ["electric1.jpg", "electric2.jpg", "electric3.jpg"];

        const randomIndex = Math.floor(Math.random() * 3);

        switch (category) {
            case "engine":
                return `images/engine/${engineImages[randomIndex]}`;
            case "brakes":
                return `images/brakes/${brakesImages[randomIndex]}`;
            case "tires":
                return `images/tires/${tiresImages[randomIndex]}`;
            case "filter":
                return `images/filter/${filterImages[randomIndex]}`;
            case "electric":
                return `images/electric/${electricImages[randomIndex]}`;
            default:
                return "images/placeholder.png";
        }
    }

    const addPartForm = document.getElementById("addPartForm");
    if (addPartForm) {
        addPartForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const partName = document.getElementById("partName").value;
            const partCategory = document.getElementById("partCategory").value;
            const partPrice = document.getElementById("partPrice").value;

            addCarPart(partName, partCategory, partPrice);

            // Optionally, you can reset the form fields after adding a part
            addPartForm.reset();

            // Optionally, you can navigate back to the main page
            window.location.href = "main.html";
        });
    }
    // Code for the main page
    if (window.location.pathname.includes("main.html")) {
        const searchInput = document.getElementById("search");
        const categorySelect = document.getElementById("category");

        // Function to filter and display components
        function filterComponents() {
            const selectedCategory = categorySelect.value.toLowerCase();
            const searchTerm = searchInput.value.toLowerCase();

            const carParts = getCarPartsFromLocalStorage();
            const filteredComponents = carParts.filter(component => {
                const categoryMatch = selectedCategory === "all" || component.category.toLowerCase() === selectedCategory;
                const searchMatch = component.name.toLowerCase().includes(searchTerm);
                return categoryMatch && searchMatch;
            });

            displayComponents(filteredComponents);
        }

        // Event listeners for category select and search input
        categorySelect.addEventListener("change", filterComponents);
        searchInput.addEventListener("input", filterComponents);

        // Initial display of components
        const components = getCarPartsFromLocalStorage();
        displayComponents(components);
    }

    function clearCart() {
        localStorage.removeItem("shoppingCart");
    }
});
